// =========================
// NAVIGATION
// =========================

function showSection(id) {

    document.querySelectorAll(".section").forEach(section => {
        section.classList.remove("active");
    });

    document.getElementById(id).classList.add("active");
}

function logout() {
    alert("Logged Out Successfully");
}

// =========================
// FOOD MANAGEMENT
// =========================

let foods = [];

function addFood() {

    let name = document.getElementById("name").value;
    let price = document.getElementById("price").value;
    let url = document.getElementById("url").value;
    let desc = document.getElementById("desc").value;
    let stock = document.getElementById("stock").value;

    if (name === "" || price === "") {
        alert("Please Fill All Fields");
        return;
    }

    foods.push({
        name,
        price,
        url,
        desc,
        stock
    });

    renderFood();

    document.getElementById("name").value = "";
    document.getElementById("price").value = "";
    document.getElementById("url").value = "";
    document.getElementById("desc").value = "";
}

function renderFood() {

    let foodList = document.getElementById("foodList");

    foodList.innerHTML = "";

    foods.forEach(food => {

        foodList.innerHTML += `

        <div class="food-item">

            <h3>${food.name}</h3>

            <p><strong>Price:</strong> Rs ${food.price}</p>

            <p><strong>Description:</strong> ${food.desc}</p>

            <p><strong>Status:</strong> ${food.stock}</p>

            <img src="${food.url}" width="120">

        </div>

        `;
    });
}

// =========================
// ORDERS
// =========================

let orders = [

{
customer:"Ali",
food:"Zinger Burger",
time:"10:00 AM",
location:"Rawalpindi",
status:"Delivered",
record:"New"
},

{
customer:"Sara",
food:"Pizza",
time:"10:30 AM",
location:"Islamabad",
status:"Pending",
record:"Old"
},

{
customer:"Ahmed",
food:"Shawarma",
time:"11:00 AM",
location:"Lahore",
status:"Delivered",
record:"New"
},

{
customer:"Hina",
food:"Fries",
time:"11:30 AM",
location:"Karachi",
status:"Cancelled",
record:"Old"
},

{
customer:"Bilal",
food:"Chicken Burger",
time:"12:00 PM",
location:"Rawalpindi",
status:"Delivered",
record:"New"
}

];

function renderOrders() {

    let table = document.getElementById("orderTable");

    table.innerHTML = "";

    orders.forEach(order => {

        table.innerHTML += `

        <tr>

            <td>${order.customer}</td>

            <td>${order.food}</td>

            <td>${order.time}</td>

            <td>${order.location}</td>

            <td>${order.status}</td>

            <td class="${order.record === "New" ? "status-new" : "status-old"}">

                ${order.record}

            </td>

        </tr>

        `;
    });
}

// =========================
// ORDER CHART
// =========================

function drawOrderChart() {

    let canvas = document.getElementById("orderChart");

    if (!canvas) return;

    let ctx = canvas.getContext("2d");

    canvas.width = 800;
    canvas.height = 300;

    let data = [120, 180, 140, 220, 170, 260, 210];

    let step = canvas.width / (data.length - 1);

    ctx.strokeStyle = "#3A86FF";
    ctx.lineWidth = 4;

    ctx.beginPath();

    data.forEach((value, index) => {

        let x = index * step;
        let y = canvas.height - value;

        if (index === 0)
            ctx.moveTo(x, y);
        else
            ctx.lineTo(x, y);

    });

    ctx.stroke();

    // Data Points

    data.forEach((value, index) => {

        let x = index * step;
        let y = canvas.height - value;

        ctx.fillStyle = "#3A86FF";

        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.font = "12px Arial";
        ctx.fillText(value, x - 10, y - 10);

    });
}

// =========================
// REVENUE CHART
// =========================

function drawRevenueChart() {

    let canvas = document.getElementById("revenueChart");

    if (!canvas) return;

    let ctx = canvas.getContext("2d");

    canvas.width = 800;
    canvas.height = 300;

    let year2025 = [50,70,90,110,130,150,170,190,210,230,250,270];

    let year2026 = [60,90,80,120,140,160,180,150,190,220,250,280];

    let step = canvas.width / (year2025.length - 1);

    // 2025

    ctx.strokeStyle = "#3A86FF";
    ctx.lineWidth = 3;
    ctx.beginPath();

    year2025.forEach((value,index)=>{

        let x=index*step;
        let y=canvas.height-value;

        if(index===0)
            ctx.moveTo(x,y);
        else
            ctx.lineTo(x,y);

    });

    ctx.stroke();

    // 2026

    ctx.strokeStyle = "#FF6B81";
    ctx.lineWidth = 3;
    ctx.beginPath();

    year2026.forEach((value,index)=>{

        let x=index*step;
        let y=canvas.height-value;

        if(index===0)
            ctx.moveTo(x,y);
        else
            ctx.lineTo(x,y);

    });

    ctx.stroke();
}

// =========================
// CUSTOMER CHART
// =========================

function drawCustomerChart() {

    let canvas = document.getElementById("customerChart");

    if (!canvas) return;

    let ctx = canvas.getContext("2d");

    canvas.width = 800;
    canvas.height = 300;

    let customers = [60,90,120,150,100,180,140];

    customers.forEach((value,index)=>{

        ctx.fillStyle =
        index % 2 === 0
        ? "#FF6B81"
        : "#FFB703";

        ctx.fillRect(
            40 + (index * 100),
            canvas.height - value,
            50,
            value
        );

        ctx.fillStyle = "#ffffff";
        ctx.font = "12px Arial";
        ctx.fillText(
            value,
            50 + (index * 100),
            canvas.height - value - 10
        );

    });

}

// =========================
// PAGE LOAD
// =========================

window.onload = function(){

    renderFood();
    renderOrders();

    drawOrderChart();
    drawRevenueChart();
    drawCustomerChart();

};